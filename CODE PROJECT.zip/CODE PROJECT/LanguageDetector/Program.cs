﻿using System;
using System.IO;
using System.Linq;
using System.Web;
using numl.Model;
using numl.Serialization;
using numl.Supervised;
using numl.Supervised.DecisionTree;
using numl.Utils;

namespace LanguageDetector
{
    internal class Snippet
    {
        [Label]
        public string Language { get; set; }

        [StringFeature(SplitType = StringSplitType.Word)]
        public string Code { get; set; }
    }

    internal class Program
    {
        private const string saveFile = "model.json";

        private static void Main(string[] args)
        {
            IModel model;

            Ject.AddAssembly(typeof(Program).Assembly);

            var snippets = File.ReadAllText("data.txt")
                .Split(new[] { "</pre>" }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .Select(x =>
                {
                    var lang = x.Substring("<pre lang=\"".Length);
                    lang = lang.Substring(0, lang.IndexOf('"'))
                        .Replace("++", "plusplus")
                        .Replace(".", "dot")
                        .Replace("#", "sharp")
                        .ToUpperInvariant();
                               

                    var code = HttpUtility.HtmlDecode(x.Substring($"<pre lang=\"{lang}\">".Length));

                    return new Snippet { Code = code, Language = lang };
                });

            if (!File.Exists(saveFile))
            {
                var descriptor = Descriptor.Create<Snippet>();
                var generator = new DecisionTreeGenerator();

                model = generator.Generate(descriptor, snippets);
                JsonWriter.Save(model, saveFile);
            }
            else
            {
                model = JsonReader.Read<DecisionTreeModel>(saveFile);
            }

            Console.WriteLine("Self test");
            int counter = 0;
            int fail = 0;
            foreach (var snip in snippets)
            {
                counter++;

                var lang = snip.Language;
                var detected = model.Predict(snip).Language;

                if (detected != lang)
                {
                    fail++;
                    Console.WriteLine($"FAIL {fail}/{counter} is {lang} was detected {detected}");
                }
            }

            Console.ReadLine();
        }
    }
}