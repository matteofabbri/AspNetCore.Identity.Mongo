﻿using System.Linq;

namespace UserBehaviour.Model
{
    internal class DataContext
    {
        public static User[] Users;
        public static Article[] Articles;
        public static Action[] Actions;

        static DataContext()
        {
            Users = User.Load().ToArray();
            Articles = Article.Load().ToArray();
            Actions = Action.Load().ToArray();
        }
    }
}