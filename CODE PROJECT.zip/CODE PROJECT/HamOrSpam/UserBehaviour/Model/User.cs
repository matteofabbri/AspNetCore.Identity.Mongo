﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace UserBehaviour.Model
{
    internal class User
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public static IEnumerable<User> Load()
        {
            return File.ReadAllLines("./Data/Users.txt").Select(line =>
            {
                var parts = line.Split(new[] {','}, StringSplitOptions.RemoveEmptyEntries);
                return new User
                {
                    Id = int.Parse(parts[0]),
                    Name = parts[1]
                };
            });
        }
    }
}