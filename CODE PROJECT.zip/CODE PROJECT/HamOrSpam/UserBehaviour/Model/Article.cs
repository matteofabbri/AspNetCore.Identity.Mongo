﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace UserBehaviour.Model
{
    internal class Article
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int[] Tags { get; set; }

        public IEnumerable<Action> Actions => DataContext.Actions.Where(x => x.ArticleId == Id);

        public static IEnumerable<Article> Load()
        {
            return File.ReadAllLines("./Data/Articles.txt").Select(line =>
            {
                var parts = line.Split(new[] {','}, StringSplitOptions.RemoveEmptyEntries);
                return new Article
                {
                    Id = int.Parse(parts[0]),
                    Name = parts[1],
                    Tags = parts.Skip(2).Select(x => int.Parse(x.Trim().Substring("Tag ".Length))).ToArray()
                };
            });
        }
    }
}