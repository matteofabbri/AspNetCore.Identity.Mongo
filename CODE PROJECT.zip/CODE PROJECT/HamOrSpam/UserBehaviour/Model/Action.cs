﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace UserBehaviour.Model
{
    internal class Action
    {
        public int Day { get; set; }

        public ActionType Type { get; set; }

        public int UserId { get; set; }

        public User User => DataContext.Users.First(x => x.Id == UserId);

        public int ArticleId { get; set; }

        public Article Article => DataContext.Articles.First(x => x.Id == ArticleId);

        public static IEnumerable<Action> Load()
        {
            return File.ReadAllLines("./Data/Actions.txt").Select(line =>
            {
                var parts = line.Split(new[] {','}, StringSplitOptions.RemoveEmptyEntries);
                return new Action
                {
                    Day = int.Parse(parts[0]),
                    Type = Enum.Parse<ActionType>(parts[1]),
                    UserId = int.Parse(parts[2]),
                    ArticleId = int.Parse(parts[4])
                };
            });
        }
    }
}