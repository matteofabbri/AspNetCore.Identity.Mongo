﻿namespace UserBehaviour.Model
{
    internal enum ActionType
    {
        View,
        DownVote,
        UpVote,
        Download
    }
}