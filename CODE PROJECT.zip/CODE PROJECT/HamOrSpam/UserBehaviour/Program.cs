﻿using System;
using System.Linq;
using numl.Model;
using numl.Unsupervised;
using UserBehaviour.Model;

namespace UserBehaviour
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var articlesByTagsAndActions = DataContext.Actions.Select(x => new
            {
                Id = x.ArticleId,
                Tags = x.Article.Tags,
                Day = x.Day,
                User = x.UserId,
                ActionType = x.Type
            });

            var descriptor = Descriptor.New("articlesByTagsAndActions");
            descriptor.Features = new Property{};
                

            var generator = new KMeans();
            var model = generator.Generate(descriptor, DataContext.Articles, 10);

            Console.WriteLine();

            Console.WriteLine("Hello World!");
        }
    }
}