﻿using System;
using System.IO;
using System.Linq;
using numl.Model;
using numl.Serialization;
using numl.Supervised;
using numl.Supervised.DecisionTree;
using numl.Utils;

namespace HamOrSpam
{
    internal class Message
    {
        [Label] public bool Spam { get; set; }

        [StringFeature(SplitType = StringSplitType.Word)]
        public string Body { get; set; }
    }

    internal class Program
    {
        private const string saveFile = "model.json";

        private static void Main(string[] args)
        {
            IModel model;

            Ject.AddAssembly(typeof(Program).Assembly);

            if (!File.Exists(saveFile))
            {
                var descriptor = Descriptor.Create<Message>();
                var generator = new DecisionTreeGenerator();

                var spam = File.ReadAllLines("./Data/Spam.txt").Select(line => new Message { Body = line, Spam = true });
                var ham = File.ReadAllLines("./Data/Ham.txt").Select(line => new Message { Body = line, Spam = false });

                model = generator.Generate(descriptor, spam.Concat(ham).ToArray());
                JsonWriter.Save(model, saveFile);
            }
            else
            {
                model = JsonReader.Read<DecisionTreeModel>(saveFile);
            }

            var testMessages = File.ReadAllLines("./Data/Test.txt").Select(line =>
            {
                var isSpam = line.StartsWith("Spam,");

                return new Message
                {
                    Spam = isSpam,
                    Body = isSpam ? line.Substring("Spam,".Length) : line.Substring("Ham,".Length)
                };
            }).ToArray();

            var totalCounter = 0;
            var failCounter = 0;
            foreach (var msg in testMessages)
            {
                var isSpam = msg.Spam;
                var predicted = model.Predict(msg).Spam;

                if (isSpam != predicted) failCounter++;

                totalCounter++;

                Console.WriteLine($"Analized {totalCounter}, failed: {failCounter}");
            }

            if (failCounter == 0) Console.WriteLine("100% of success rate ! :D");

            Console.ReadKey();
        }
    }
}