using System;
using System.Linq;
using Xunit;
using numl.Unsupervised;
using numl.Math.LinearAlgebra;
using System.Collections.Generic;

namespace numl.Tests.UnsupervisedTests
{
    [Trait("Category", "Unsupervised")]
    public class GMMTests
    {
        [Fact]
        public void Test_Numerical_GMM()
        {
            
        }
    }
}
